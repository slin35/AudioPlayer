export default function Playlists(state = [], action) {
   switch (action.type) {
      case 'UPDATE_PLAYLISTS':
         return action.playlists;
      case 'UPDATE_TITLE':
         return state.map(val => val.id !== action.pId ?
            val : Object.assign({}, val, { title: action.title }));
      case 'DELETE_PLAYLIST':
         return state.filter(val => val.id !== action.playlistId);
      case 'ADD_PLAYLIST':
         return state.concat([action.playlist]);
      default:
         return state;
    }
 }
 