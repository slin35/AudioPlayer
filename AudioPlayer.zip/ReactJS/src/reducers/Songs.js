export default function Songs(state = [], action) {
   switch (action.type) {
      case 'UPDATE_SONGS':
         return action.songs;
      case 'ADD_SONGS':
         return state.concat([action.songs]);
      case 'DELETE_SONG':
         return state.filter(val => val.id !== action.sId);
      case 'ADD_SONG':
         return state;
      default:
         return state;
    }
 }