export default function Likes(state = [], action) {
    switch (action.type) {
        case 'UPDATE_LIKES':
        case 'ADD_LIKES':
          return action.likeInfo;
        case 'REMOVE_LIKE':
          return state.filter(val => val.prsId !== action.prsId);
        default:
          return state;
    }
 }