import { combineReducers } from 'redux';

import Prss from './Prss';
import Playlists from './Playlists';
import Songs from './Songs';
import Errs from './Errs';
import Likes from './Likes';

const rootReducer = combineReducers({Prss, Playlists, Songs, Likes, Errs});

export default rootReducer;