export default function Errs(state = [], action) {
   switch(action.type) {
   case 'LOGIN_ERR':
   case 'REGISTER_ERR':
   case 'UPDATE_PLAYLISTS_ERR':
   case 'ADD_PLAYLIST_ERR':
   case 'SERVER_ERR':
   case 'UPDATE_SONGS_ERR':
   case 'DEL_SONG_ERR':
   case 'EDIT_TITLE_ERR':
   case 'DEL_PLAYLIST_ERR':
   case 'DEL_LIKE_ERROR':
   case 'ADD_LIKE_ERR':
   case 'UPDATE_LIKES_ERR':
      return state.concat(action.details);
   case 'CLEAR_ERRS':
      return [];
   default:
      return state;
   }
}
