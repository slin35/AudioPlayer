import React, { Component } from 'react';
import {Register, SignIn, PlaylistsOverview, PlaylistDetail, SongSearch} from '../components'
import {Route, Redirect, Switch } from 'react-router-dom';
import {Navbar, Nav, ListGroup, ListGroupItem, Modal, Button} from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap';
import './Main.css';


var ProtectedRoute = ({component: Cmp, path, ...rest }) => {
   return (<Route path={path} render={(props) => {
      return Object.keys(rest.Prss).length !== 0 ?
      <Cmp {...rest}/> : <Redirect to='/signin'/>;}}/>);
   };
   
class Main extends Component {

   constructor(props) {
      super(props);

      this.state = {
         showError: false
      }
   }
   
   signedIn() {
      return Object.keys(this.props.Prss).length !== 0;
   }

   render() {
      var errors = [];
      var count = 0;

      console.log("Redrawing main");
      this.props.Errs.forEach(err => {
         errors.push(<ErrItem
          key={count}
          errMsg={err} />);
         count += 1;
       });
      
      return (
         <div>
            <div>
               <Navbar expand="lg">
                  <Navbar.Toggle aria-controls="basic-navbar-nav"/>
                  <Navbar.Collapse >
                     <Nav variant="pills">
                        {this.signedIn() ?
                           [
                              <LinkContainer to='/allPlaylists' key={0}>
                                 <Nav.Link> All Playlists</Nav.Link>
                              </LinkContainer>,
                              <LinkContainer to='/myPlaylists' key={1}>
                                 <Nav.Link>My Playlists</Nav.Link>
                              </LinkContainer>,
                              <LinkContainer to='/songSearch' key={2}>
                                 <Nav.Link>Song Search</Nav.Link>
                              </LinkContainer>
                              
                           ]
                           :
                           [
                              <LinkContainer to='/signin' key={0}>
                                 <Nav.Link>Sign In</Nav.Link>
                              </LinkContainer>,
                              <LinkContainer to='/register' key={1}>
                                 <Nav.Link>Register</Nav.Link>
                              </LinkContainer>
                           ]
                        }
                        </Nav>

                        {this.signedIn() ?               //if signed in, give signout option
                                                   // NOTE: any time an array in JSX, iteration, forloop, etc is created as
                                                   // below, key property is necessary
                        [
                           <Nav variant="pills" className="ml-auto" key={0}>
                           <Nav.Item onClick={() => { console.log(this.props);
                              this.props.signOut();}}
                              key={1}>
                              <Nav.Link href="/signin">Sign Out</Nav.Link>
                           </Nav.Item>
                           </Nav>
                        ]
                        :
                        ''           //otherwise just put nothing
                        }
                  </Navbar.Collapse>
               </Navbar>
            </div>

            {/*Alternate pages beneath navbar, based on current route*/}
            
            <Switch>
               <Route exact path='/'
                  component={() => this.props.Prss ? <Redirect to="/allPlaylists" />
                   : <Redirect to="/signin" />} />
               <Route path='/signin' render={() => <SignIn {...this.props} />} />
               <Route path='/register'
                render={() => <Register {...this.props} />} />
               <ProtectedRoute path='/allPlaylists' component={PlaylistsOverview}
                {...this.props}/>
               <ProtectedRoute path='/myPlaylists' component={PlaylistsOverview}
                userOnly={true} {...this.props}/>
               <ProtectedRoute path='/PlaylistDetail/:id' component={PlaylistDetail}
                {...this.props}/>
               <ProtectedRoute path='/songSearch' component={SongSearch}
                {...this.props}/>
               
               />
            </Switch>

            {/*Error popup dialog*/}
            {this.props.Errs.length ?
            
         <Modal show={this.props.Errs.length > 0} onHide={() => {
                this.props.clearErrors();
                return this.setState({showError: false})}}>
            <Modal.Header closeButton>
               <Modal.Title>{"Error Message"}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
               {errors.length ? errors : []}
            </Modal.Body>
            <Modal.Footer>
               <Button onClick={() => {
                this.props.clearErrors();
                return this.setState({showError: false});}}>
               {'OK'}
               </Button>
            </Modal.Footer>
         </Modal>
         : ""}

         </div>
      )
   }
}

const ErrItem = function (props) {
   return (
      <ListGroup>
         <ListGroupItem>
               {props.errMsg}
         </ListGroupItem>
      </ListGroup>
   )
}

export default Main
