import React, {Component} from 'react';
import {ListGroup, ListGroupItem, Col,
 Row, Button, Modal, Form, FormGroup, FormControl} from 'react-bootstrap';
import ReactAudioPlayer from 'react-audio-player';
import { withRouter, Redirect } from 'react-router';


const component = class PlaylistDetail extends Component {
   constructor(props) {
      super(props);

      this.pId = parseInt(this.props.match.params.id);
      this.props.updateLikes(this.pId);
      this.props.updateSongs(this.pId);
      this.liked = this.checkIfLiked();

      this.state = {
       showEditModal: false,
       showDelWarning: false,
       editTitle: "",
       liked: this.liked,
       redirect: false,
       removeSong: false
      }
      
      this.checkIfLiked();
      this.getPlaylist();
   }

   confirmEdit = (result) => {
      if (result === "Confirm") {
         this.props.editPlaylistTitle(this.pId, this.state.editTitle);
      }
      this.setState({showEditModal: false, editTitle: ""});
   }

   confirmDelete = (result) => {
      var newState = {showDelWarning: false}
      if (result === "Confirm"){
         this.props.deletePlaylist(this.pId)
      }
      this.setState(newState);
   }

   toggleLike = () => {
      if (this.state.liked)
         this.props.removeLike(this.pId);
      else
         this.props.addLike(this.pId);
      this.props.updateLikes(this.pId);
      this.setState({liked: !this.state.liked});
   }

   checkIfLiked = () => {
      var didLike;
      this.props.Likes.forEach( (likeInfo) => {
         if (this.props.Prss.id === likeInfo.prsId) {
            didLike = true;
         }
      });
      if (didLike === undefined)
         didLike = false;
      return didLike;
   };

   getPlaylist() {
      this.props.Playlists.forEach( (p) => {
      if (this.pId === p.id) {
         this.playlist = p;
      }});
   }

   getSongs() {
      return this.props.updateSongs(this.pId);
   }

   removeSong(sId, boundThis) {
      boundThis.props.removeSong(boundThis.pId, sId);
      boundThis.setState({removeSong: !boundThis.state.removeSong});
   }

   handleChange = (e) => {
      this.setState({editTitle: e.target.value});
   }

   render() {
      var songItems = [];
      var name;
      this.getPlaylist();
      this.props.Songs.forEach(song => {
         songItems.push(<SongItem
            key={songItems.length}
            sId={song.id}
            title={song.title}
            artist={song.artist}
            genre={song.genre}
            link={song.link}
            isOwner={this.props.Prss.id === this.playlist.ownerId}
            removeSong={this.removeSong}
            oldThis={this}
            {...song} />);
      });
      name = this.props.Prss.firstName + " " + this.props.Prss.lastName;

      return (
         <section className="container">
            <Row>
               <Col xs={{span: 4, offset: 8}} md={{span: 12, offset: 0}}>
                  <p className="text-right">
                     {`${"Logged in as:"} ${name}`}
                  </p>
               </Col>
            </Row>

            <Row>
               <Col xs={8}>
                  <h1>{this.playlist.title}</h1>
               </Col>
               <Col style={{paddingRight: 0 }}>
               {this.props.Prss.id ===  this.playlist.ownerId ?
                  <div className="float-right">
                     {this.props.Likes.length} <span
                      className="fa fa-thumbs-o-up"></span>
                     <Button className="border m-2" size="sm" onClick={() =>
                      this.setState({showEditModal: true})}>
                        <span className="fa fa-edit"/>
                     </Button>
                     <Button size="sm" onClick={() =>
                      this.setState({showDelWarning: true})}>
                        <span className="fa fa-trash"/>
                     </Button>
                  </div>
                  :  <div className="float-right">
                        {this.props.Likes.length} <Button size="sm"
                         onClick={() => this.toggleLike()}
                         variant={this.state.liked ? "success" : "primary"}>
                           <span className="fa fa-thumbs-o-up"></span>
                        </Button>
                     </div>}
               </Col>
            </Row>

            
            {songItems.length ?
            <div>
            <Row> 
             <Col xs={4} sm={4}>
                Title
             </Col>
             <Col xs={3} sm={3}>
                Artist
             </Col>
             <Col xs={3} sm={3}>
                Genre
             </Col>
            </Row>
            <ListGroup>
               {songItems}
            </ListGroup>
            </div>
            : (this.playlist.ownerId === this.props.Prss.id ?
             "You haven't added anything to this playlist yet"
            : "The owner of this playist hasn't added anything to it yet." +
             " Come back later to check in!")}


            {/*This is the delete module*/}
            <PlaylistModal
             show={this.state.showDelWarning}
             title="Delete Playlist"
             body={"Are you sure you'd like to delete this playlist?" +
             " Once you click away, you won't be able to revisit it."}
             onClose={this.confirmDelete} />

            {/*This is the edit module*/}
            <PlaylistModal
             show={this.state.showEditModal}
             title="Edit Playlist Title"
             body={
               <form onSubmit={(e) =>
               e.preventDefault() || this.state.editTitle.length ?
               this.confirmEdit("Confirm") : this.confirmEdit("Cancel")}>
                  <FormGroup controlId="formBasicText">
                     <Form.Label>
                        What would you liked to re-name your playlist?
                     </Form.Label>
                     <FormControl
                        type="text"
                        value={this.state.editTitle}
                        placeholder={this.playlist.title}
                        onChange={this.handleChange}
                     />
                     <FormControl.Feedback />
                     <Form.Text className="text-muted">
                       Title is required
                     </Form.Text>
                  </FormGroup>
               </form>}
             onClose={this.confirmEdit} />

            {this.state.redirect ? <Redirect to='/myPlaylists' /> : ""}
            
         </section>
      )
   }
}

const PlaylistModal = function(props) {
   return(
      <Modal show={props.show} onHide={() => props.onClose("Dismissed")}>
         <Modal.Header closeButton>
            <Modal.Title>{props.title}</Modal.Title>
         </Modal.Header>
         <Modal.Body>
            {props.body}
         </Modal.Body>
         <Modal.Footer>
               <Button onClick={() => props.onClose("Confirm")}>
                  Confirm
               </Button>
               <Button onClick={() => props.onClose("Cancel")}>
                  Cancel
               </Button>
         </Modal.Footer>
      </Modal>
   );
}

const SongItem = function (props) {
   return (
      <ListGroupItem>
         <Row> 
            <Col xs={4} sm={4}>
               {props.title}
            </Col>
            <Col xs={3} sm={3}>
               {props.artist}
            </Col>
            <Col xs={3} sm={3}>
               {props.genre}
            </Col>
            <Col>
               {props.isOwner ?
                  <div className="float-right">
                     <Button onClick={() =>
                      props.removeSong(props.sId, props.oldThis)}>
                        <span className="fa fa-trash" />
                     </Button>
                  </div>
               : ''}
            </Col>
         </Row>
         <ReactAudioPlayer
            src={props.link}
            controls/>
      </ListGroupItem>
   )
 }

export default withRouter(component);