import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import {ListGroup, ListGroupItem, Col, Row, Button} from 'react-bootstrap';
import {PlaylistModal} from '../components';

export default class PlaylistsOverview extends Component {
   constructor(props) {
      super(props);

      this.props.updatePlaylists();
      this.state = {
         showModal: false,
         showConfirmation: false,
      }
   }

   openModal = () => {
      this.setState({
         showModal: true,
      });
   }

   modalDismiss = (result) => {
      if (result.status === "Ok") {
         this.newPlaylist(result);
      }
      this.setState({ showModal: false});
   }

   newPlaylist(result) {
      this.props.addPlaylist({ title: result.title });
   }

   render() {
      var playlistItems = [];
      var name = this.props.Prss.firstName + " " + this.props.Prss.lastName;

      this.props.Playlists.forEach(playlist => {
         playlist.id = playlist.id ? playlist.id :
          this.props.Playlists.length;
         if (!this.props.userOnly || this.props.Prss.id === playlist.ownerId)
            playlistItems.push(<PlaylistItem
             key={playlist.id}
             {...playlist}
             isOwner={playlist.ownerId === this.props.Prss.id} />);
      });

      return (
         <section className="container">
            <Row>
               <Col xs={{span: 4, offset: 8}} md={{span: 6, offset: 9}}>
                  <p className="text-left">
                     {`${"Logged in as:"} ${name}`}
                  </p>
               </Col>
            </Row>
            {this.props.userOnly ?
            <h1>My Playlists</h1> : <h1>Playlists</h1>}
            <ListGroup>
               {playlistItems}
            </ListGroup>
            <Button className="border mt-1" variant="primary" onClick=
             {() => {this.openModal()}}>New Playlist</Button>

            <PlaylistModal
             showModal={this.state.showModal}
             title={"New Playlist"}
             onDismiss={this.modalDismiss} />
         </section>
      )
   }
}

const PlaylistItem = function (props) {
   return (
      <ListGroupItem>
         <Row> 
            <Col xs={4} sm={4}>
               <Link to={"/PlaylistDetail/" + props.id}>{props.title}</Link>
            </Col>
            <Col xs={3} sm={3}>
               {props.numLikes} <span className="fa fa-thumbs-o-up"></span>
            </Col>
            <Col xs={3} sm={3}>
               {new Intl.DateTimeFormat('us',
               {
                  year: "numeric", month: "short", day: "numeric",
                  hour: "2-digit", minute: "2-digit", second: "2-digit"
               })
            .format(new Date(props.whenMade * 1000))}
            </Col>
            <Col>
               {props.isOwner ?
                  <div className="float-right">
                     <span className="fa fa-user-circle" />
                  </div>
               : ''}
            </Col>
         </Row>
      </ListGroupItem>
   )
}