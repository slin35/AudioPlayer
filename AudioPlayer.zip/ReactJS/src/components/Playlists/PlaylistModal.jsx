import React, { Component } from 'react';
import {Modal, Button, Form, FormControl, FormGroup} from 'react-bootstrap';

export default class PlaylistModal extends Component {
   constructor(props) {
      super(props);
      this.state = {
         playlistTitle: (this.props.playlist && this.props.playlist.title)
          || "",
      }
   }

   close = (result) => {
      this.props.onDismiss && this.props.onDismiss({
         status: result,
         title: this.state.playlistTitle
      });
   }

   handleChange = (e) => {
      this.setState({playlistTitle: e.target.value});
   }

   componentWillReceiveProps = (nextProps) => {
      if (nextProps.showModal) {
         this.setState(
          {playlistTitle: (nextProps.playlist && nextProps.playlist.title)
           || "" })
      }
   }

   formValid() {
      return this.state.playlistTitle.length;
   }

   render() {
      return (
         <Modal show={this.props.showModal}
          onHide={() => this.close("Cancel")}>
            <Modal.Header closeButton>
               <Modal.Title>{this.props.title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
               <form onSubmit={(e) =>
                e.preventDefault() || this.state.playlistTitle.length ?
                this.close("Ok") : this.close("Cancel")}>
                  <FormGroup controlId="formBasicText">
                     <Form.Label>Playlist Title</Form.Label>
                     <FormControl
                      type="text"
                      value={this.state.playlistTitle}
                      placeholder="Enter your awesome playlist title here!"
                      onChange={this.handleChange}
                     />
                     <FormControl.Feedback />
                     <Form.Text className="text-muted">
                        Title is required
                     </Form.Text>
                  </FormGroup>
               </form>
            </Modal.Body>
            <Modal.Footer>
               <Button onClick={() => this.close("Ok")}
                disabled={!this.formValid()}>
                  Ok
               </Button>
               <Button onClick={() => this.close("Cancel")}>Cancel</Button>
            </Modal.Footer>
         </Modal>)
   }
}