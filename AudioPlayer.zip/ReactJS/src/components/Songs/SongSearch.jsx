import React, {Component} from 'react';
import {ListGroup, ListGroupItem, Col,
 Row, Dropdown, DropdownButton, Form, FormGroup}
 from 'react-bootstrap';
import ReactAudioPlayer from 'react-audio-player';
import { withRouter } from 'react-router';


const component = class SongSearch extends Component {
   constructor(props) {
      super(props);

      this.props.updateSearchSongs(this.title, this.artist, this.genre);

      this.state = {
       title: "",
       artist: "",
       genre: ""
      }
   }

   getSongs() {
      return this.props.updateSearchSongs(this.pId);
   }

   handleTitleChange = (e) => {
      this.setState({title: e.target.value});
   }

   handleArtistChange = (e) => {
      this.setState({artist: e.target.value});
   }

   handleGenreChange = (e) => {
      this.setState({genre: e.target.value});
   }

   addToPlaylist = (sId, pId) => {
      this.props.addPlaylistSong(sId, pId);
   }

   render() {
      var songItems = [];
      var name;
      var playlists = this.props.Playlists.filter(p => {
         return p.ownerId === this.props.Prss.id;
      });
   
      this.props.Songs.forEach(song => {
         if (song.title.includes(this.state.title)
          && song.artist.includes(this.state.artist)
          && song.genre.includes(this.state.genre)) {
         songItems.push(<SongItem
            key={songItems.length}
            sId={song.id}
            title={song.title}
            artist={song.artist}
            genre={song.genre}
            oldThis={this}
            onClick={this.addToPlaylist}
            playlists={playlists}
            {...song} />);
         }
      });
      name = this.props.Prss.firstName + " " + this.props.Prss.lastName;
      
      return (
         <section className="container">
            <Row>
               <Col xs={{span: 4, offset: 8}} md={{span: 12, offset: 0}}>
                  <p className="text-right">
                     {`${"Logged in as:"} ${name}`}
                  </p>
               </Col>
            </Row>

            <h1>Song Search</h1>
            <form>
               <Row>
                  <Col xs={4}>
                     <FormGroup controlId={"title"}>
                        <Form.Label>{"Title"}</Form.Label>
                        <Form.Control value={this.state.title}
                         onChange={this.handleTitleChange} />
                     </FormGroup>
                  </Col>
                  <Col xs={3}>
                     <FormGroup controlId={"artist"}>
                        <Form.Label>{"Artist"}</Form.Label>
                        <Form.Control value={this.state.artist}
                         onChange={this.handleArtistChange} />
                     </FormGroup>
                  </Col>
                  <Col xs={3}>
                     <FormGroup controlId={"genre"}>
                        <Form.Label>{"Genre"}</Form.Label>
                        <Form.Control value={this.state.genre}
                         onChange={this.handleGenreChange} />
                     </FormGroup>
                  </Col>
               </Row>
            </form>

            
            {songItems.length ?
            <div>
            <Row> 
             <Col xs={4} sm={4}>
                Title
             </Col>
             <Col xs={3} sm={3}>
                Artist
             </Col>
             <Col xs={3} sm={3}>
                Genre
             </Col>
            </Row>
         
            <ListGroup>
               {songItems}
            </ListGroup></div>
            : "None of the songs in our library match your search."
            + " Try changing your search inputs, or check back later"
            + " to see if we've added your song!"}
         </section>
      )
   }
}

const SongItem = function (props) {

   var dropButtons = [];
   
   props.playlists.forEach(playlist => {
         dropButtons.push(
          <Dropdown.Item eventKey={playlist.id} key={playlist.id}
           onSelect={() => props.oldThis.addToPlaylist(props.sId, playlist.id)}>
            {playlist.title}
          </Dropdown.Item>);
   });

    return (
      <ListGroupItem>
         <Row> 
            <Col xs={4} sm={4}>
               {props.title}
            </Col>
            <Col xs={3} sm={3}>
               {props.artist}
            </Col>
            <Col xs={2} sm={2}>
               {props.genre}
            </Col>
            <Col xs={2}>
               <DropdownButton id="dropdown-basic-button"
                title="Add to Playlist">
                  {dropButtons}
               </DropdownButton>
            </Col>
            <Col>
            <ReactAudioPlayer
               src={props.link}
               controls/>
            </Col>
         </Row>
      </ListGroupItem>
   )
}

export default withRouter(component);