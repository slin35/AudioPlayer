import * as api from '../api';

export function signIn(credentials, cb) {
   return (dispatch, prevState) => {
      api.signIn(credentials)
      .then((userInfo) => {
         return dispatch({type: "SIGN_IN", user: userInfo});})
      .then(() => {if (cb) cb();})
      .catch(error => {
         return dispatch({type: 'LOGIN_ERR', details: error});})
   };
}

export function signOut(cb) {
   return (dispatch, prevState) => {
      api.signOut()
       .then(() => dispatch({ type: 'SIGN_OUT' }))
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'REGISTER_ERR', details: error}))
   };
}

export function register(data, cb) {
   return (dispatch, prevState) => {
      api.register(data)
       .then(() => {if (cb) cb();})
       .catch(error => {
         dispatch({type: 'REGISTER_ERR', details: error});});
   };
}

export function clearErrors(cb) {
   return (dispatch, prevState) => {
      dispatch({type: 'CLEAR_ERRS'});
   };
}

export function handleServerError(err) {
   return (dispatch, prevState) => {
      return dispatch({type: 'SERVER_ERR', details: ["Server Connect Error"]});
   };
}

export function updatePlaylists(userId, cb) {
   return (dispatch, prevState) => {
      api.getPlaylists(userId)
       .then((playlists) => {
       return dispatch({ type: 'UPDATE_PLAYLISTS', playlists: playlists });
      })
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'UPDATE_PLAYLISTS_ERR'}));
   };
}

export function addPlaylist(body, cb) {
   return (dispatch, prevState) => {
      api.postPlaylist(body)
       .then(playlistRsp => dispatch({type: 'ADD_PLAYLIST', playlist: playlistRsp}))
       .then(() => {if (cb) cb();})
       .catch(error => {
         return dispatch({type: 'ADD_PLAYLIST_ERR', details: error});
      })
   };
}

export function updateLikes(pId, cb) {
   return (dispatch, prevState) => {
      api.getLikes(pId)
       .then((likeInfo) => {
         return dispatch({ type: 'UPDATE_LIKES', likeInfo: likeInfo });
      })
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'UPDATE_LIKES_ERR'}));
   };
}

export function addLike(pId, cb) {
   return (dispatch, prevState) => {
      api.postLike(pId)
       .then(likeInfo => dispatch({type: 'ADD_LIKE', likes: likeInfo}))
       .then(() => {if (cb) cb();})
       .catch(error => {
         return dispatch({type: 'ADD_LIKE_ERR', details: error});
      })
   };
}

export function removeLike(pId, cb) {
   return (dispatch, prevState) => {
      api.delLike(pId)
       .then(() => dispatch({type: 'DELETE_LIKE', pId: pId}))
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'DEL_LIKE_ERROR', details: error}))
   };
}

export function deletePlaylist(pId, cb) {
   return (dispatch, prevState) => {
      api.delPlaylist(pId)
       .then(() => {dispatch({type: 'DELETE_PLAYLIST', pId: pId})})
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'DEL_PLAYLIST_ERR', details: error}))
   };
}

export function editPlaylistTitle(pId, title, cb) {
   return (dispatch, prevState) => {
      api.putPlaylist(pId, {title})
       .then(() => dispatch({type: 'UPDATE_TITLE', pId: pId, title: title}))
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'EDIT_TITLE_ERR', details: error}))
   };
}

export function updateSongs(pId, cb) {
   return (dispatch, prevState) => {
      api.getSongs(pId)
       .then((songs) => {
       return dispatch({ type: 'UPDATE_SONGS', songs: songs });
      })
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'UPDATE_SONGS_ERR'}));
   };
}

export function removeSong(pId, sId, cb) {
   return (dispatch, prevState) => {
      api.delPlaylistSong(pId, sId)
       .then(() => {dispatch({type: 'DELETE_SONG', sId: sId})})
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'DEL_SONG_ERR', details: error}))
   };
}

export function updateSearchSongs(title, artist, genre, cb) {
   return (dispatch, prevState) => {
      api.getSearchSongs(title, artist, genre)
       .then((songs) => {
       return dispatch({ type: 'UPDATE_SONGS', songs: songs });
      })
       .then(() => {if (cb) cb();})
       .catch(error => dispatch({type: 'UPDATE_SONGS_ERR'}));
   };
}

export function addPlaylistSong(sId, pId, cb) {
   return (dispatch, prevState) => {
      api.postPlaylistSong(sId, pId)
       .then(() => dispatch({type: 'ADD_SONG'}))
       .then(() => {if (cb) cb();})
       .catch(error => {
         return dispatch({type: 'ADD_SONG_ERROR'});
      })
   };
}